Prerequitisites
===============
Java,Maven,testng plugin for eclipse installed and environmental path should be set up
https://www.java.com/en/download/
download java8
https://maven.apache.org/download.html
install testng plugin to run tests from eclipse ide
Tests Can be ran from eclipse ide or Command prompt
Latest ChromeBrowser and Firefox Browser for Windows 10 OS

examples to confirm installation:
Go to folder of this project files
verify java and Maven Installation from below commands
make sure java and maven environmental path is setup

C:\Users\preeth\Desktop\New folder>java -version
java version "1.8.0_181"
Java(TM) SE Runtime Environment (build 1.8.0_181-b13)
Java HotSpot(TM) 64-Bit Server VM (build 25.181-b13, mixed mode)

C:\Users\preeth\Desktop\New folder>mvn -version
Apache Maven 3.5.2 (138edd61fd100ec658bfa2d307c43b76940a5d7d; 2017-10-18T09:58:13+02:00)
Maven home: E:\installation\apache-maven-3.5.2\bin\..
Java version: 10, vendor: Oracle Corporation
Java home: C:\Program Files\Java\jdk-10
Default locale: en_ZA, platform encoding: Cp1252
OS name: "windows 10", version: "10.0", arch: "amd64", family: "windows"
=========================================================================================

	Runs the tests from command prompt:
	mvn clean compile -> make sure there are no errors
	from command prompt:
	//to run tests only on chrome
	mvn -DtestngFileName=chrome.xml test
	//to  run tests only on firefox
	mvn -DtestngFileName=firefox.xml test
	//  run tests on both browsers crossbrowsera
	mvn -DtestngFileName=crossbrowser.xml test
	
  
  # viewing the results and reports and screenshots
  "Extent\extentreport.html"
  Extent report file will be generated here,
  #if any failure scrrenshots will be attached to this report as well
  "Extent\" Failed screenshots are captured here
  
  # Log-files are generated and stored in below location
  log\
  
===========================================================================================
Example trace of Execution from command prompt
C:\Users\preeth\Desktop\New folder>mvn clean compile
[INFO] Scanning for projects...
[INFO]
[INFO] ------------------------------------------------------------------------
[INFO] Building web-test 1.0-SNAPSHOT
[INFO] ------------------------------------------------------------------------
[INFO]
[INFO] --- maven-clean-plugin:2.5:clean (default-clean) @ web-test ---
[INFO]
[INFO] --- maven-resources-plugin:2.6:resources (default-resources) @ web-test ---
[INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] Copying 3 resources
[INFO]
[INFO] --- maven-compiler-plugin:3.1:compile (default-compile) @ web-test ---
[INFO] Nothing to compile - all classes are up to date
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 3.293 s
[INFO] Finished at: 2018-10-20T18:53:48+02:00
[INFO] Final Memory: 10M/40M
[INFO] ------------------------------------------------------------------------

C:\Users\preeth\Desktop\New folder>mvn -DtestngFileName=chrome.xml test
[INFO] Scanning for projects...
[INFO]
[INFO] ------------------------------------------------------------------------
[INFO] Building web-test 1.0-SNAPSHOT
[INFO] ------------------------------------------------------------------------
[INFO]
[INFO] --- maven-resources-plugin:2.6:resources (default-resources) @ web-test ---
[INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] Copying 3 resources
[INFO]
[INFO] --- maven-compiler-plugin:3.1:compile (default-compile) @ web-test ---
[INFO] Nothing to compile - all classes are up to date
[INFO]
[INFO] --- maven-resources-plugin:2.6:testResources (default-testResources) @ web-test ---
[INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] Copying 0 resource
[INFO]
[INFO] --- maven-compiler-plugin:3.1:testCompile (default-testCompile) @ web-test ---
[INFO] Changes detected - recompiling the module!
[INFO] Compiling 5 source files to C:\Users\preeth\Desktop\New folder\target\test-classes
[INFO]
[INFO] --- maven-surefire-plugin:2.19:test (default-test) @ web-test ---

-------------------------------------------------------
 T E S T S
-------------------------------------------------------
Running TestSuite
Starting ChromeDriver 2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a) on port 25918
Only local connections are allowed.
Oct 20, 2018 6:56:26 PM org.openqa.selenium.remote.ProtocolHandshake createSession
INFO: Detected dialect: OSS
Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 18.829 sec - in TestSuite

Results :

Tests run: 1, Failures: 0, Errors: 0, Skipped: 0

[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 24.786 s
[INFO] Finished at: 2018-10-20T18:56:41+02:00
[INFO] Final Memory: 16M/54M
[INFO] ------------------------------------------------------------------------
===================================================================================================
