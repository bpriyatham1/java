package com.relayr.utilities;

import org.apache.commons.lang3.RandomStringUtils;
import com.relayr.tests.TestBase;

public class Utils extends TestBase {

	public final static long PAGE_LOAD_TIMEOUT = 15;
	public final static long IMPLICIT_WAIT = 10;

	public static String generaterandomname(int length) {
		String rn = RandomStringUtils.randomAlphabetic(length);
		return rn;
	}

}
